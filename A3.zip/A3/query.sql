create database A3

use A3
create table Gift(
	GiftId int primary key identity,
	GiftName varchar(255),
	GiftPrice decimal,
	GiftColor varchar(255),
)

create table Orders(
	OrderId int primary key identity,
	TotalPrice decimal,
	[Address] varchar(255),
	Phone varchar(255),
)

create table OrderDetails(
	OrderDetailId int primary key identity,
	TotalGift int,
	TotalPrice decimal,
	OrderId int,
	GiftId int
)

Alter table OrderDetails
add
Constraint fk_detail_id_orders foreign key (OrderId) references [Orders](OrderId),
Constraint fk_detail_id_gift foreign key (GiftId) references [Gift](GiftId)

Alter table Gift
add GiftPhoto varchar(255),
GiftPath varchar(255)

Alter table Orders
add TotalGift int

insert into Gift(GiftName,GiftPrice,GiftColor,GiftPath,GiftPhoto) values
('wisdon','1000.00','White','1.jpg'),
('mscience','99999.00','Violet','2.jpg'),
('kaka,'8.00',2333.00','3.jpg'),
