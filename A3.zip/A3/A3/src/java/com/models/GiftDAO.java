package com.models;

import java.util.List;

public interface GiftDAO {
    public List<Gift> findAll();
    public Gift get(int id);
    public List<Gift> findByName(String name);
}
