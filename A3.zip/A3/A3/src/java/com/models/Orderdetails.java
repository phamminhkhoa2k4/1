package com.models;

import java.math.BigDecimal;


public class Orderdetails {
    private int orderDetailId;
    private int totalGift;
    private Double totalPrice;
    private int orderId;
    private int giftId;

    public Orderdetails() {
    }

    public Orderdetails(int orderDetailId, int totalGift, BigDecimal totalPrice, int orderId, int giftId) {
        this.orderDetailId = orderDetailId;
        this.totalGift = totalGift;
        this.totalPrice = totalPrice.doubleValue();
        this.orderId = orderId;
        this.giftId = giftId;
    }

    public int getOrderDetailId() {
        return orderDetailId;
    }

    public void setOrderDetailId(int orderDetailId) {
        this.orderDetailId = orderDetailId;
    }

    public int getTotalGift() {
        return totalGift;
    }

    public void setTotalGift(int totalGift) {
        this.totalGift = totalGift;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(BigDecimal totalPrice) {
        this.totalPrice = totalPrice.doubleValue();
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getGiftId() {
        return giftId;
    }

    public void setGiftId(int giftId) {
        this.giftId = giftId;
    }
    
    
    
    
}
