package com.models;

import java.math.BigDecimal;
import java.util.List;

public class Orders {
    private int orderId;
    private List<Orderdetails> orderdetails;
    private int totalGift;
    private Double totalPrice;
    private String phone;
    private String address;

    public Orders() {
        this.orderId = 0;
        this.totalGift = 0;
        this.totalPrice = 0.0;
        this.phone = "";
        this.address = "";
    }

    public Orders(int orderId, int totalGift, BigDecimal totalPrice, String phone, String address) {
        this.orderId = orderId;
        this.totalGift = totalGift;
        this.totalPrice = totalPrice.doubleValue();
        this.phone = phone;
        this.address = address;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public List<Orderdetails> getOrderdetails() {
        return orderdetails;
    }

    public void setOrderdetails(List<Orderdetails> orderdetails) {
        this.orderdetails = orderdetails;
    }

    public int getTotalGift() {
        return totalGift;
    }

    public void setTotalGift(int totalGift) {
        this.totalGift = totalGift;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(BigDecimal totalPrice) {
        this.totalPrice = totalPrice.doubleValue();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
    
}
