package com.models;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

public class OrdersDAOImpl implements OrdersDAO{

    private JdbcTemplate jdbcTemplate;
    
    public OrdersDAOImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    
    public OrdersDAOImpl() {
    }
    
    @Override
    public int Add(Orders order) {
        String sql = "INSERT INTO Orders(TotalGift,TotalPrice,[Address],Phone) VALUES (?,?,?,?)";

        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, order.getTotalGift());
            ps.setDouble(2, order.getTotalPrice());
            ps.setString(3, order.getAddress());
            ps.setString(4, order.getPhone());
            return ps;
        }, keyHolder);

        int orderId = keyHolder.getKey().intValue();

        return orderId;
    }

    @Override
    public Orderdetails AddOrderdetails(Orderdetails od, int orderId) {
        String sql = "INSERT INTO Orderdetails(TotalGift,TotalPrice,OrderId,GiftId) VALUES (?,?,?,?)";
        jdbcTemplate.update(sql, od.getTotalGift(), od.getTotalPrice(), orderId, od.getGiftId());
        return od;
    }
    
    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    
}
