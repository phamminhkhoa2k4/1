package com.models;

public class CartItem {
    private int quantity;
    private int giftId;
    private String giftName;
    private double giftPrice;
    private String giftColor;
    private String giftPhoto;
    private String giftPath;

    public CartItem() {
        this.quantity = 0;
        this.giftId = 0;
        this.giftName = "";
        this.giftPrice = 0.0;
        this.giftColor = "";
        this.giftPhoto = "";
        this.giftPath = "";
    }

    public CartItem(int quantity, int giftId, String giftName, double giftPrice, String giftColor, String giftPhoto, String giftPath) {
        this.quantity = quantity;
        this.giftId = giftId;
        this.giftName = giftName;
        this.giftPrice = giftPrice;
        this.giftColor = giftColor;
        this.giftPhoto = giftPhoto;
        this.giftPath = giftPath;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getGiftId() {
        return giftId;
    }

    public void setGiftId(int giftId) {
        this.giftId = giftId;
    }

    public String getGiftName() {
        return giftName;
    }

    public void setGiftName(String giftName) {
        this.giftName = giftName;
    }

    public double getGiftPrice() {
        return giftPrice;
    }

    public void setGiftPrice(double giftPrice) {
        this.giftPrice = giftPrice;
    }

    public String getGiftColor() {
        return giftColor;
    }

    public void setGiftColor(String giftColor) {
        this.giftColor = giftColor;
    }

    public String getGiftPhoto() {
        return giftPhoto;
    }

    public void setGiftPhoto(String giftPhoto) {
        this.giftPhoto = giftPhoto;
    }

    public String getGiftPath() {
        return giftPath;
    }

    public void setGiftPath(String giftPath) {
        this.giftPath = giftPath;
    }
    
    
}
