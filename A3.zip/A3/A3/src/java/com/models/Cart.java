package com.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;


public class Cart implements Serializable {
    private List<CartItem> items;
    
    public Cart(){
        items = new ArrayList<>();
    }
    
    //add
    public void addItem(int quantity, double price, String name, int id, String color, String photo, String path, HttpSession session){
    boolean itemExists = false;
    for (CartItem item : items) {
        if (item.getGiftId()== id) {
            item.setQuantity(item.getQuantity() + quantity);
            itemExists = true;
            break;
        }
    }
    
    if (!itemExists) {
        CartItem newItem = new CartItem(quantity, id, name, price, color, photo, path);
        items.add(newItem);
    }
    
    session.setAttribute("cart", this);
    }
    
    //remove
    public void removeItem(int id, HttpSession session){
        for(int i = 0; i < items.size(); i++){
            CartItem item = items.get(i);
            if(item.getGiftId() == id){
                items.remove(i);
                session.setAttribute("cart", this);
                return;
            }
        }
    }
    
    public void clear(HttpSession session){
        items.clear();
        session.removeAttribute("cart");
    }
    
    //All Product
    public List<CartItem> getItems(){
        return items;
    }
    
    public int getTotalQuantity(){
        int totalQuantity = 0;
        for(CartItem item : items){
            totalQuantity += item.getQuantity();
        }
        return totalQuantity;
    }
    
    public double getTotalPrice(){
        double totalPrice = 0;
        for(CartItem item : items){
            totalPrice += item.getGiftPrice() * item.getQuantity();
        }
        return totalPrice;
    }
    
}
