package com.models;

public interface OrdersDAO {
    public int Add(Orders order);
    public Orderdetails AddOrderdetails(Orderdetails od, int id);
}
