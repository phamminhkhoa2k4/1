package com.models;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class GiftDAOImpl implements GiftDAO{
    
    private JdbcTemplate jdbcTemplate;
    
    public GiftDAOImpl(){
        
    }
    
    @Override
    public List<Gift> findAll() {
        String sql = "select * from Gift";
        List<Gift> gift = new ArrayList<>();
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
        for(Map row : rows){
            Gift obj = new Gift((int) row.get("GiftId"), (String) row.get("GiftName"), (BigDecimal) row.get("GiftPrice"), (String) row.get("GiftColor"), (String) row.get("GiftPhoto"), (String) row.get("GiftPath"));
            gift.add(obj);
        }
        return gift;
    }

    @Override
    public Gift get(int id) {
        String sql = "select * from Gift where GiftId = ?";
        return jdbcTemplate.queryForObject(sql, new Object[]{id}, new RowMapper<Gift>(){
            @Override
            public Gift mapRow(ResultSet rs, int row)throws SQLException {
                Gift gift = new Gift();
                gift.setGiftId(rs.getInt("GiftId"));
                gift.setGiftName(rs.getString("GiftName"));
                gift.setGiftPrice(rs.getBigDecimal("GiftPrice"));
                gift.setGiftColor(rs.getString("GiftColor"));
                gift.setGiftPhoto(rs.getString("GiftPhoto"));
                gift.setGiftPath(rs.getString("GiftPath"));
                return gift;
            }
        });
    }
    
    @Override
    public List<Gift> findByName(String name) {
        String sql = "select * from Gift where GiftName like ?";
        String keyword = "%" + name + "%";
        List<Gift> gift = new ArrayList<>();
        
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql, keyword);
        for(Map<String, Object> row : rows){
            Gift gifts = new Gift();
            gifts.setGiftId((int) row.get("GiftId"));
            gifts.setGiftName((String) row.get("GiftName"));
            gifts.setGiftPrice((BigDecimal)row.get("GiftPrice"));
            gifts.setGiftColor((String) row.get("GiftColor"));
            gifts.setGiftPhoto((String) row.get("GiftPhoto"));
            gifts.setGiftPath((String) row.get("GiftPath"));
            gift.add(gifts);
        }
        return gift;
    }
    
    public GiftDAOImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
}
