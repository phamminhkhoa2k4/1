package com.controllers;

import com.models.Cart;
import com.models.CartItem;
import com.models.Gift;
import com.models.GiftDAO;
import com.models.Orderdetails;
import com.models.Orders;
import com.models.OrdersDAO;
import java.math.BigDecimal;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping(value = "/")
public class GiftController {

    @Autowired
    private GiftDAO giftDAO;

    @Autowired
    private OrdersDAO ordersDAO;

    @Autowired
    private HttpSession session;

    @RequestMapping(value = "Welcome")
    public String Welcome() {
        return "Welcome";
    }

    @RequestMapping(value = "Gift")
    public String GiftPage(String name, ModelMap model) {
        model.addAttribute("listGift", giftDAO.findAll());
        return "Gift";
    }

    @RequestMapping(value = "displayData", method = RequestMethod.POST)
    public String DisplayData(String name, ModelMap model) {
         if (name.equals("")) {
            model.addAttribute("alert", "Please enter your name");
            return "Welcome";
        } else {
            session.setAttribute("name", name);
            model.addAttribute("alert", "");
            model.addAttribute("listGift", giftDAO.findAll());
            session.setAttribute("listGift", model.addAttribute("listGift", giftDAO.findAll()));
            return "Gift";
         }
    }

    @RequestMapping(value = "detail", method = RequestMethod.GET)
    public String DisplayByName(int id, ModelMap model) {
        Gift gift = giftDAO.get(id);
        model.addAttribute("giftId", gift.getGiftId());
        model.addAttribute("giftName", gift.getGiftName());
        model.addAttribute("giftPrice", gift.getGiftPrice());
        model.addAttribute("giftColor", gift.getGiftColor());
        model.addAttribute("giftPhoto", gift.getGiftPhoto());
        model.addAttribute("giftPath", gift.getGiftPath());
        return "Detail";
    }

    @RequestMapping(value = "cartadd", method = RequestMethod.GET)
    public String addCart(int id, String name, ModelMap model, HttpServletResponse response) {
        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null) {
            cart = new Cart();
        }

        Gift gift = giftDAO.get(id);
        cart.addItem(1, gift.getGiftPrice(), gift.getGiftName(), id, gift.getGiftColor(), gift.getGiftPhoto(), gift.getGiftPath(), session);
        model.addAttribute("listCart", cart.getItems());
        model.addAttribute("totalQuan", cart.getTotalQuantity());
        model.addAttribute("totalPrice", cart.getTotalPrice());
        return "Cart";
    }

    @RequestMapping(value = "remove", method = RequestMethod.GET)
    public String removeCart(int id, ModelMap model) {
        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null) {
            cart = new Cart();
        }
        cart.removeItem(id, session);
        model.addAttribute("listCart", cart.getItems());
        model.addAttribute("totalQuan", cart.getTotalQuantity());
        model.addAttribute("totalPrice", cart.getTotalPrice());
        return "Cart";
    }
    
    @RequestMapping(value = "Order", method = RequestMethod.GET)
    public String checkout(ModelMap model) {
        Cart cart = (Cart) session.getAttribute("cart");
        model.addAttribute("listCart", cart.getItems());
        model.addAttribute("totalQuan", cart.getTotalQuantity());
        model.addAttribute("totalPrice", cart.getTotalPrice());
        return "Checkout";
    }

    @RequestMapping(value = "Checkout", method = RequestMethod.POST)
    public String Order(String address, String phone, ModelMap model, HttpSession session) {
        Cart cart = (Cart) session.getAttribute("cart");

        if (cart == null) {
            return "Welcome";
        } else {
            Orders order = new Orders();
            order.setAddress(address);
            order.setPhone(phone);
            order.setTotalGift(cart.getTotalQuantity());
            if(cart.getTotalPrice() >= 55.00){
                order.setTotalPrice(BigDecimal.valueOf(cart.getTotalPrice() * .75));
            }else{
                order.setTotalPrice(BigDecimal.valueOf(cart.getTotalPrice()));
            }
            int orderID = ordersDAO.Add(order);

            List<CartItem> items = cart.getItems();
            if (items == null || items.isEmpty()) {
                return "displayData";
            } else {
                for (CartItem item : items) {
                    Orderdetails ods = new Orderdetails();
                    ods.setOrderId(orderID);
                    ods.setGiftId(item.getGiftId());
                    ods.setTotalGift(item.getQuantity());
                    ods.setTotalPrice(BigDecimal.valueOf(item.getGiftPrice()));
                    ordersDAO.AddOrderdetails(ods, orderID);
                }
                session.removeAttribute("cart");
                model.addAttribute("listGift", giftDAO.findAll());
                return "Gift";
            }
        }
    }
    
    @RequestMapping(value = "SearchByName", method = RequestMethod.GET)
    public String SearchByName(String name, ModelMap model, HttpSession session){
        if(name.equals("")){
            model.addAttribute("listGift", giftDAO.findAll());
        }else{
            List<Gift> listGift = giftDAO.findByName(name);
            model.addAttribute("listGift", listGift);
        }
        return "Gift";
    }
    
    @RequestMapping(value = "removeAll", method = RequestMethod.GET)
    public String RemoveAllCart(ModelMap model, HttpSession session){
        Cart cart = (Cart) session.getAttribute("cart");
        if(cart != null){
            cart.clear(session);
            session.removeAttribute("cart");
        }
        return "Cart";
    }
}
